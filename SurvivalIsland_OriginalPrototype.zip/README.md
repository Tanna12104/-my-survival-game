# Survival Island – Original Mobile Prototype

โปรเจกต์ต้นแบบ Unity สำหรับเกม survival 3D บนมือถือ
แนวทางการออกแบบอิงจากภาพตัวอย่างที่ผู้ใช้ส่งมาในระดับ "ประเภทเกม/ระบบ" เท่านั้น
ไม่ได้คัดลอก source code, asset, texture, model, เสียง หรือ UI ที่เป็นทรัพย์สินของเกมต้นฉบับ

## ระบบที่รวมมาให้
- Procedural island map + ocean
- Day/Night cycle
- Third-person mobile player
- Virtual joystick + touch action buttons
- HP / Hunger / Thirst / Stamina
- Inventory + hotbar
- Item database
- Resource gathering
- Crafting
- Building placement
- Weapons / melee / ranged projectile
- Wildlife AI
- Damage / death / respawn
- Save / load JSON
- Basic quest/event hooks
- Mobile-friendly HUD
- Runtime bootstrap: สร้างโลกและ UI โดยไม่ต้องทำ prefab จำนวนมาก

## วิธีเริ่ม
1. สร้าง Unity 6 3D project ใหม่
2. นำโฟลเดอร์ `Assets/Scripts` ไปไว้ใน `Assets/`
3. สร้าง Empty GameObject ชื่อ `Game`
4. ใส่ component `GameBootstrap`
5. กด Play

หมายเหตุ:
- Prototype นี้ใช้ primitive ของ Unity เพื่อให้เริ่มทดลองได้ทันที
- ถ้าจะทำเกมจริง ควรเปลี่ยน primitive เป็นโมเดล, animation, VFX, sound และ texture ของคุณเอง
- สำหรับมือถือ แนะนำให้เปิด URP และทำ object pooling/LOD ก่อนเพิ่มจำนวน NPC และทรัพยากร

## โครงสร้างระบบ
GameBootstrap
 ├─ WorldGenerator
 ├─ DayNightCycle
 ├─ PlayerController
 ├─ SurvivalStats
 ├─ Inventory
 ├─ CraftingSystem
 ├─ BuildingSystem
 ├─ WildlifeAI
 ├─ WeaponSystem
 ├─ SaveSystem
 └─ MobileHUD

## การควบคุมต้นแบบ
- เดิน: joystick ซ้าย
- มุมกล้อง: ลากพื้นที่ด้านขวา
- โจมตี/ใช้ของ: ปุ่ม Action
- สลับของ: แตะ hotbar
- เก็บทรัพยากร: เข้าใกล้แล้วกด Gather
