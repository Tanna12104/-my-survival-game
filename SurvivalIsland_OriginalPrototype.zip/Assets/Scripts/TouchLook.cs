using UnityEngine;
using UnityEngine.EventSystems;

public class TouchLook : MonoBehaviour, IDragHandler
{
    public CameraFollow cameraFollow;
    public void OnDrag(PointerEventData eventData)
    {
        if (!cameraFollow) cameraFollow = Camera.main.GetComponent<CameraFollow>();
        if (cameraFollow) cameraFollow.Orbit(eventData.delta);
    }
}