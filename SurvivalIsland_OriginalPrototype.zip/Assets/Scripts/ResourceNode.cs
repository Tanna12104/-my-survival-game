using UnityEngine;

public enum ResourceType { Wood, Stone, Food }

public class ResourceNode : MonoBehaviour
{
    public ResourceType resourceType;
    public int amount = 5;

    public void Gather(Inventory inventory)
    {
        string id = resourceType == ResourceType.Wood ? "wood" :
                    resourceType == ResourceType.Stone ? "stone" : "berry";
        if (inventory.Add(id, 1))
        {
            amount--;
            if (amount <= 0) Destroy(gameObject);
        }
    }
}