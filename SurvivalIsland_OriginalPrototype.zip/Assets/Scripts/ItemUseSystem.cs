using UnityEngine;

public class ItemUseSystem : MonoBehaviour
{
    public void UseSelected()
    {
        var inv = GetComponent<Inventory>();
        var stats = GetComponent<SurvivalStats>();
        var stack = inv.Selected;
        if (stack == null) return;

        if (stack.itemId == "berry" && inv.Remove("berry", 1)) stats.Eat(12);
        else if (stack.itemId == "water" && inv.Remove("water", 1)) stats.Drink(25);
    }
}