using UnityEngine;

public class SurvivalStats : MonoBehaviour
{
    public float maxHealth = 100, health = 100;
    public float maxHunger = 100, hunger = 100;
    public float maxThirst = 100, thirst = 100;
    public float maxStamina = 100, stamina = 100;

    public bool Dead => health <= 0;

    void Update()
    {
        hunger = Mathf.Max(0, hunger - Time.deltaTime * .45f);
        thirst = Mathf.Max(0, thirst - Time.deltaTime * .7f);

        if (hunger <= 0 || thirst <= 0)
            health = Mathf.Max(0, health - Time.deltaTime * 2f);

        stamina = Mathf.Min(maxStamina, stamina + Time.deltaTime * 8f);
    }

    public void Damage(float value)
    {
        if (Dead) return;
        health = Mathf.Max(0, health - value);
        if (Dead) Invoke(nameof(Respawn), 2f);
    }

    public void Heal(float value) => health = Mathf.Min(maxHealth, health + value);
    public void Eat(float value) => hunger = Mathf.Min(maxHunger, hunger + value);
    public void Drink(float value) => thirst = Mathf.Min(maxThirst, thirst + value);

    void Respawn()
    {
        transform.position = Vector3.up * 3;
        health = maxHealth * .6f;
        hunger = 60; thirst = 60;
    }
}