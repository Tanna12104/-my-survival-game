using UnityEngine;
using System.Collections.Generic;
using System.Linq;

[System.Serializable]
public class InventoryStack
{
    public string itemId;
    public int amount;
    public InventoryStack(string id, int n) { itemId = id; amount = n; }
}

public class Inventory : MonoBehaviour
{
    public int slots = 24;
    public List<InventoryStack> items = new();
    public int selectedSlot;

    public bool Add(string id, int amount = 1)
    {
        if (!ItemDatabase.Items.ContainsKey(id)) return false;
        int max = ItemDatabase.Items[id].maxStack;

        var stack = items.FirstOrDefault(x => x.itemId == id && x.amount < max);
        if (stack != null)
        {
            int add = Mathf.Min(amount, max - stack.amount);
            stack.amount += add;
            amount -= add;
        }

        while (amount > 0 && items.Count < slots)
        {
            int add = Mathf.Min(amount, max);
            items.Add(new InventoryStack(id, add));
            amount -= add;
        }
        return amount == 0;
    }

    public bool Remove(string id, int amount)
    {
        for (int i = items.Count - 1; i >= 0 && amount > 0; i--)
        {
            if (items[i].itemId != id) continue;
            int take = Mathf.Min(amount, items[i].amount);
            items[i].amount -= take;
            amount -= take;
            if (items[i].amount <= 0) items.RemoveAt(i);
        }
        return amount <= 0;
    }

    public int Count(string id) => items.Where(x => x.itemId == id).Sum(x => x.amount);
    public InventoryStack Selected => selectedSlot >= 0 && selectedSlot < items.Count ? items[selectedSlot] : null;
}