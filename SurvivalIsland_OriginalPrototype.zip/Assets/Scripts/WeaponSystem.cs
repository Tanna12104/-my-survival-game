using UnityEngine;

public class WeaponSystem : MonoBehaviour
{
    public float meleeRange = 2.5f;
    public float meleeDamage = 20f;
    public Transform muzzle;

    public void Attack()
    {
        if (Physics.Raycast(transform.position + Vector3.up, transform.forward, out RaycastHit hit, meleeRange))
        {
            var target = hit.collider.GetComponentInParent<SurvivalStats>();
            if (target && target.gameObject != gameObject) target.Damage(meleeDamage);
            var node = hit.collider.GetComponent<ResourceNode>();
            if (node) node.Gather(GetComponent<Inventory>());
        }
    }

    public void Shoot()
    {
        Vector3 origin = muzzle ? muzzle.position : transform.position + Vector3.up * 1.4f;
        Vector3 dir = transform.forward;
        if (Physics.Raycast(origin, dir, out RaycastHit hit, 60))
        {
            var target = hit.collider.GetComponentInParent<SurvivalStats>();
            if (target && target.gameObject != gameObject) target.Damage(25);
        }
    }
}