using UnityEngine;
using System.IO;

[System.Serializable]
public class SaveData
{
    public Vector3 playerPosition;
    public float health, hunger, thirst;
}

public class SaveSystem : MonoBehaviour
{
    string Path => System.IO.Path.Combine(Application.persistentDataPath, "survival_save.json");

    public void Save()
    {
        var p = FindFirstObjectByType<PlayerController>();
        var s = FindFirstObjectByType<SurvivalStats>();
        if (!p || !s) return;

        var data = new SaveData {
            playerPosition = p.transform.position,
            health = s.health, hunger = s.hunger, thirst = s.thirst
        };
        File.WriteAllText(Path, JsonUtility.ToJson(data, true));
    }

    public void Load()
    {
        if (!File.Exists(Path)) return;
        var data = JsonUtility.FromJson<SaveData>(File.ReadAllText(Path));
        var p = FindFirstObjectByType<PlayerController>();
        var s = FindFirstObjectByType<SurvivalStats>();
        if (p) p.transform.position = data.playerPosition;
        if (s) { s.health = data.health; s.hunger = data.hunger; s.thirst = data.thirst; }
    }

    void OnApplicationPause(bool paused) { if (paused) Save(); }
    void OnApplicationQuit() => Save();
}