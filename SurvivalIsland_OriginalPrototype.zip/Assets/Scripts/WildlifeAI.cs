using UnityEngine;

public class WildlifeAI : MonoBehaviour
{
    public float wanderRadius = 12;
    public float speed = 1.8f;
    public float detectDistance = 10;
    Vector3 target;
    float nextDecision;

    void Start() => PickTarget();

    void Update()
    {
        var player = FindFirstObjectByType<PlayerController>();
        if (player && Vector3.Distance(transform.position, player.transform.position) < detectDistance)
        {
            Vector3 away = (transform.position - player.transform.position).normalized;
            target = transform.position + away * 8f;
        }
        else if (Time.time > nextDecision) PickTarget();

        Vector3 dir = target - transform.position;
        dir.y = 0;
        if (dir.magnitude > .8f)
        {
            transform.position += dir.normalized * speed * Time.deltaTime;
            transform.rotation = Quaternion.LookRotation(dir.normalized);
        }
    }

    void PickTarget()
    {
        target = transform.position + Random.insideUnitSphere * wanderRadius;
        target.y = transform.position.y;
        nextDecision = Time.time + Random.Range(2f, 5f);
    }
}