using UnityEngine;
using System.Collections.Generic;

[System.Serializable]
public class Recipe
{
    public string result;
    public int resultAmount;
    public Dictionary<string,int> cost;
}

public class CraftingSystem : MonoBehaviour
{
    public static CraftingSystem Instance;
    public Inventory inventory;

    void Awake() => Instance = this;

    public bool Craft(string result)
    {
        if (!inventory) inventory = FindFirstObjectByType<Inventory>();
        if (result == "axe")
        {
            if (inventory.Count("wood") >= 8 && inventory.Count("stone") >= 4)
            {
                inventory.Remove("wood", 8); inventory.Remove("stone", 4);
                return inventory.Add("axe", 1);
            }
        }
        if (result == "bow")
        {
            if (inventory.Count("wood") >= 12)
            {
                inventory.Remove("wood", 12);
                return inventory.Add("bow", 1);
            }
        }
        if (result == "wall")
        {
            if (inventory.Count("wood") >= 6)
            {
                inventory.Remove("wood", 6);
                return inventory.Add("wall", 1);
            }
        }
        return false;
    }
}