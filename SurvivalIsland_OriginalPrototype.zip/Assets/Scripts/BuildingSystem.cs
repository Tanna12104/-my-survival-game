using UnityEngine;

public class BuildingSystem : MonoBehaviour
{
    public static BuildingSystem Instance;
    public Material previewMaterial;
    GameObject preview;

    void Awake() => Instance = this;

    public void StartPlacement(string itemId)
    {
        if (preview) Destroy(preview);
        preview = GameObject.CreatePrimitive(PrimitiveType.Cube);
        preview.name = "BuildPreview";
        preview.transform.localScale = itemId == "wall" ? new Vector3(3,2.5f,.25f) : Vector3.one;
        var col = preview.GetComponent<Collider>(); if (col) col.enabled = false;
        previewMaterial = new Material(Shader.Find("Universal Render Pipeline/Lit"));
        if (previewMaterial.shader == null) previewMaterial = new Material(Shader.Find("Standard"));
        previewMaterial.color = new Color(1,1,1,.35f);
        preview.GetComponent<Renderer>().material = previewMaterial;
    }

    public void Place(Vector3 position, Quaternion rotation, string itemId)
    {
        var p = GameObject.CreatePrimitive(PrimitiveType.Cube);
        p.name = itemId;
        p.transform.position = position;
        p.transform.rotation = rotation;
        p.transform.localScale = itemId == "wall" ? new Vector3(3,2.5f,.25f) : Vector3.one;
        if (itemId == "campfire")
        {
            p.transform.localScale = Vector3.one * 1.3f;
        }
        preview?.SetActive(false);
    }
}