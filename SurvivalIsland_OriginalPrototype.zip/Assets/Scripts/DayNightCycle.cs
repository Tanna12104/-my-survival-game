using UnityEngine;

public class DayNightCycle : MonoBehaviour
{
    public float dayLengthSeconds = 900f;
    public Light sun;
    public float time01 = .25f;

    void Start()
    {
        var go = new GameObject("Sun");
        sun = go.AddComponent<Light>();
        sun.type = LightType.Directional;
        sun.intensity = 1.1f;
    }

    void Update()
    {
        time01 = (time01 + Time.deltaTime / dayLengthSeconds) % 1f;
        sun.transform.rotation = Quaternion.Euler(time01 * 360f - 90f, 30f, 0);
        sun.intensity = Mathf.Lerp(.08f, 1.15f, Mathf.Clamp01(Mathf.Sin(time01 * Mathf.PI)));
    }
}