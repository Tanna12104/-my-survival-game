using UnityEngine;
using System.Collections.Generic;

public class WorldGenerator : MonoBehaviour
{
    public int seed = 12345;
    public int size = 180;
    public float height = 18f;
    public float noiseScale = 0.045f;
    public int resourceCount = 100;

    public Vector3 GetSpawnPoint() => new Vector3(0, 2, 0);

    public void Generate()
    {
        Random.InitState(seed);
        CreateIsland();
        CreateWater();
        SpawnResources();
    }

    void CreateIsland()
    {
        var go = new GameObject("Island");
        var mf = go.AddComponent<MeshFilter>();
        var mr = go.AddComponent<MeshRenderer>();
        var mc = go.AddComponent<MeshCollider>();

        int v = size + 1;
        Vector3[] verts = new Vector3[v * v];
        Vector2[] uv = new Vector2[verts.Length];
        int[] tris = new int[size * size * 6];

        for (int z = 0; z < v; z++)
        for (int x = 0; x < v; x++)
        {
            float nx = (x - size * .5f) / (size * .5f);
            float nz = (z - size * .5f) / (size * .5f);
            float radial = Mathf.Clamp01(1f - new Vector2(nx, nz).magnitude);
            float n = Mathf.PerlinNoise((x + seed) * noiseScale, (z + seed) * noiseScale);
            float y = Mathf.Max(0, Mathf.Pow(radial, 1.7f) * (n * .75f + .25f) * height);
            int i = z * v + x;
            verts[i] = new Vector3(x - size * .5f, y, z - size * .5f);
            uv[i] = new Vector2((float)x / size, (float)z / size);
        }

        int t = 0;
        for (int z = 0; z < size; z++)
        for (int x = 0; x < size; x++)
        {
            int a = z * v + x;
            int b = a + 1;
            int c = a + v;
            int d = c + 1;
            tris[t++] = a; tris[t++] = c; tris[t++] = b;
            tris[t++] = b; tris[t++] = c; tris[t++] = d;
        }

        var mesh = new Mesh { name = "ProceduralIsland" };
        mesh.indexFormat = UnityEngine.Rendering.IndexFormat.UInt32;
        mesh.vertices = verts; mesh.triangles = tris; mesh.uv = uv;
        mesh.RecalculateNormals();
        mf.sharedMesh = mesh;
        mc.sharedMesh = mesh;

        var mat = new Material(Shader.Find("Universal Render Pipeline/Lit"));
        if (mat.shader == null) mat = new Material(Shader.Find("Standard"));
        mat.color = new Color(.28f, .46f, .20f);
        mr.sharedMaterial = mat;
    }

    void CreateWater()
    {
        var water = GameObject.CreatePrimitive(PrimitiveType.Plane);
        water.name = "Ocean";
        water.transform.position = new Vector3(0, .15f, 0);
        water.transform.localScale = Vector3.one * (size / 10f);
        var r = water.GetComponent<Renderer>();
        r.material.color = new Color(.08f, .35f, .55f, .8f);
    }

    void SpawnResources()
    {
        for (int i = 0; i < resourceCount; i++)
        {
            Vector2 p = Random.insideUnitCircle * (size * .42f);
            Vector3 pos = new Vector3(p.x, 20, p.y);
            if (Physics.Raycast(pos, Vector3.down, out RaycastHit hit, 50))
            {
                if (hit.point.y < .5f) continue;
                PrimitiveType type = i % 3 == 0 ? PrimitiveType.Cube :
                                     i % 3 == 1 ? PrimitiveType.Cylinder :
                                     PrimitiveType.Sphere;
                var r = GameObject.CreatePrimitive(type);
                r.name = i % 3 == 0 ? "TreeResource" : i % 3 == 1 ? "RockResource" : "BerryResource";
                r.transform.position = hit.point + Vector3.up * .7f;
                r.transform.localScale = i % 3 == 0 ? new Vector3(1,2.5f,1) : Vector3.one * 1.1f;
                var gather = r.AddComponent<ResourceNode>();
                gather.resourceType = (ResourceType)(i % 3);
                gather.amount = Random.Range(3, 9);
            }
        }
    }
}