using UnityEngine;
using UnityEngine.UI;

public class GameBootstrap : MonoBehaviour
{
    public int seed = 12345;
    public bool randomSeed = true;

    void Start()
    {
        if (randomSeed) seed = Random.Range(1, int.MaxValue);

        var world = new GameObject("World");
        var generator = world.AddComponent<WorldGenerator>();
        generator.seed = seed;
        generator.Generate();

        var player = new GameObject("Player");
        player.transform.position = generator.GetSpawnPoint() + Vector3.up * 2f;
        player.AddComponent<CharacterController>();
        player.AddComponent<PlayerController>();
        player.AddComponent<SurvivalStats>();
        player.AddComponent<Inventory>();
        player.AddComponent<WeaponSystem>();

        var cam = new GameObject("Main Camera");
        cam.tag = "MainCamera";
        cam.AddComponent<Camera>();
        var follow = cam.AddComponent<CameraFollow>();
        follow.target = player.transform;

        var systems = new GameObject("Systems");
        systems.AddComponent<DayNightCycle>();
        systems.AddComponent<CraftingSystem>();
        systems.AddComponent<BuildingSystem>();
        systems.AddComponent<SaveSystem>();

        var canvasGO = new GameObject("MobileHUD");
        var canvas = canvasGO.AddComponent<Canvas>();
        canvas.renderMode = RenderMode.ScreenSpaceOverlay;
        canvasGO.AddComponent<CanvasScaler>();
        canvasGO.AddComponent<GraphicRaycaster>();
        var hud = canvasGO.AddComponent<MobileHUD>();
        hud.player = player.GetComponent<PlayerController>();
        hud.stats = player.GetComponent<SurvivalStats>();
        hud.inventory = player.GetComponent<Inventory>();
    }
}