using UnityEngine;

public class CameraFollow : MonoBehaviour
{
    public Transform target;
    public float distance = 6f;
    public float height = 3f;
    public float sensitivity = 0.15f;
    float yaw = 35f;
    float pitch = 15f;

    void LateUpdate()
    {
        if (!target) return;
        Vector3 euler = new Vector3(pitch, yaw, 0);
        Vector3 offset = Quaternion.Euler(euler) * new Vector3(0, 0, -distance);
        transform.position = target.position + Vector3.up * height + offset;
        transform.LookAt(target.position + Vector3.up * 1.2f);
    }

    public void Orbit(Vector2 delta)
    {
        yaw += delta.x * sensitivity;
        pitch = Mathf.Clamp(pitch - delta.y * sensitivity, -10, 55);
    }
}