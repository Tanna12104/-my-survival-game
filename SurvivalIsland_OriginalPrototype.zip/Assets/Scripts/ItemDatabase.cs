using UnityEngine;
using System.Collections.Generic;

public enum ItemType { Wood, Stone, Food, Water, Weapon, Tool, Building }

[System.Serializable]
public class ItemData
{
    public string id;
    public string displayName;
    public ItemType type;
    public int maxStack = 20;
    public int damage;
    public int nutrition;
    public int hydration;
}

public static class ItemDatabase
{
    public static readonly Dictionary<string, ItemData> Items = new()
    {
        {"wood", new ItemData{ id="wood", displayName="Wood", type=ItemType.Wood, maxStack=50 }},
        {"stone", new ItemData{ id="stone", displayName="Stone", type=ItemType.Stone, maxStack=50 }},
        {"berry", new ItemData{ id="berry", displayName="Berry", type=ItemType.Food, maxStack=20, nutrition=12 }},
        {"water", new ItemData{ id="water", displayName="Water", type=ItemType.Water, maxStack=10, hydration=25 }},
        {"axe", new ItemData{ id="axe", displayName="Axe", type=ItemType.Tool, maxStack=1 }},
        {"bow", new ItemData{ id="bow", displayName="Bow", type=ItemType.Weapon, maxStack=1, damage=25 }},
        {"wall", new ItemData{ id="wall", displayName="Wall", type=ItemType.Building, maxStack=20 }},
        {"campfire", new ItemData{ id="campfire", displayName="Campfire", type=ItemType.Building, maxStack=5 }}
    };
}