using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;

public class MobileHUD : MonoBehaviour
{
    public PlayerController player;
    public SurvivalStats stats;
    public Inventory inventory;

    Text hp, hunger, thirst, hotbar;
    GameObject panel;

    void Start()
    {
        if (!FindFirstObjectByType<EventSystem>())
            new GameObject("EventSystem", typeof(EventSystem), typeof(StandaloneInputModule));

        hp = MakeText("HP", new Vector2(30,-30), 22);
        hunger = MakeText("Hunger", new Vector2(30,-60), 20);
        thirst = MakeText("Thirst", new Vector2(30,-90), 20);
        hotbar = MakeText("Hotbar", new Vector2(30,30), 18);

        var attack = MakeButton("ATTACK", new Vector2(-85,90), new Vector2(150,70));
        attack.onClick.AddListener(() => player.GetComponent<WeaponSystem>().Attack());

        var gather = MakeButton("GATHER", new Vector2(-85,170), new Vector2(150,60));
        gather.onClick.AddListener(() => player.GetComponent<WeaponSystem>().Attack());

        var craft = MakeButton("CRAFT AXE", new Vector2(-85,250), new Vector2(150,60));
        craft.onClick.AddListener(() => {
            var c = FindFirstObjectByType<CraftingSystem>();
            c.inventory = inventory;
            c.Craft("axe");
        });

        var eat = MakeButton("EAT", new Vector2(85,90), new Vector2(130,60));
        eat.onClick.AddListener(() => {
            if (inventory.Remove("berry",1)) stats.Eat(12);
        });

        var move = MakeJoystick(new Vector2(110,110));
        move.onValueChanged.AddListener(v => player.SetMove(v));

        InvokeRepeating(nameof(UpdateText), 0, .1f);
    }

    void UpdateText()
    {
        hp.text = $"HP {stats.health:0}/{stats.maxHealth:0}";
        hunger.text = $"Hunger {stats.hunger:0}";
        thirst.text = $"Thirst {stats.thirst:0}";
        hotbar.text = inventory.Selected != null ?
            $"Selected: {inventory.Selected.itemId} x{inventory.Selected.amount}" :
            "Selected: empty";
    }

    Text MakeText(string name, Vector2 pos, int size)
    {
        var go = new GameObject(name);
        go.transform.SetParent(transform, false);
        var t = go.AddComponent<Text>();
        t.font = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
        t.fontSize = size;
        t.color = Color.white;
        t.rectTransform.anchorMin = new Vector2(0,1);
        t.rectTransform.anchorMax = new Vector2(0,1);
        t.rectTransform.anchoredPosition = pos;
        t.rectTransform.sizeDelta = new Vector2(500,40);
        return t;
    }

    Button MakeButton(string label, Vector2 pos, Vector2 size)
    {
        var go = new GameObject(label);
        go.transform.SetParent(transform, false);
        var img = go.AddComponent<Image>();
        img.color = new Color(0,0,0,.45f);
        var b = go.AddComponent<Button>();
        b.GetComponent<RectTransform>().anchorMin = new Vector2(1,0);
        b.GetComponent<RectTransform>().anchorMax = new Vector2(1,0);
        b.GetComponent<RectTransform>().anchoredPosition = pos;
        b.GetComponent<RectTransform>().sizeDelta = size;
        var text = MakeText(label+"Text", Vector2.zero, 16);
        text.transform.SetParent(go.transform, false);
        text.rectTransform.anchorMin = Vector2.zero;
        text.rectTransform.anchorMax = Vector2.one;
        text.rectTransform.offsetMin = Vector2.zero;
        text.rectTransform.offsetMax = Vector2.zero;
        text.alignment = TextAnchor.MiddleCenter;
        text.text = label;
        return b;
    }

    Slider MakeJoystick(Vector2 pos)
    {
        var go = new GameObject("VirtualJoystick");
        go.transform.SetParent(transform, false);
        var s = go.AddComponent<Slider>();
        s.minValue = -1; s.maxValue = 1;
        s.value = 0;
        s.direction = Slider.Direction.LeftToRight;
        s.GetComponent<RectTransform>().anchorMin = new Vector2(0,0);
        s.GetComponent<RectTransform>().anchorMax = new Vector2(0,0);
        s.GetComponent<RectTransform>().anchoredPosition = pos;
        s.GetComponent<RectTransform>().sizeDelta = new Vector2(220,80);
        return s;
    }
}