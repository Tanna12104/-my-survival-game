using UnityEngine;

public class PlayerController : MonoBehaviour
{
    public float moveSpeed = 4.5f;
    public float rotationSpeed = 10f;
    public float gravity = -20f;
    public Vector2 moveInput;
    public Transform cameraTransform;

    CharacterController cc;
    float verticalVelocity;

    void Awake()
    {
        cc = GetComponent<CharacterController>();
        cameraTransform = Camera.main ? Camera.main.transform : null;
    }

    void Update()
    {
        if (!cameraTransform && Camera.main) cameraTransform = Camera.main.transform;

        Vector3 forward = cameraTransform ? cameraTransform.forward : Vector3.forward;
        Vector3 right = cameraTransform ? cameraTransform.right : Vector3.right;
        forward.y = right.y = 0;
        Vector3 dir = (forward.normalized * moveInput.y + right.normalized * moveInput.x);
        if (dir.sqrMagnitude > 1) dir.Normalize();

        cc.Move(dir * moveSpeed * Time.deltaTime);

        if (dir.sqrMagnitude > .01f)
        {
            Quaternion target = Quaternion.LookRotation(dir);
            transform.rotation = Quaternion.Slerp(transform.rotation, target, rotationSpeed * Time.deltaTime);
        }

        if (cc.isGrounded && verticalVelocity < 0) verticalVelocity = -2;
        verticalVelocity += gravity * Time.deltaTime;
        cc.Move(Vector3.up * verticalVelocity * Time.deltaTime);
    }

    public void SetMove(Vector2 input) => moveInput = Vector2.ClampMagnitude(input, 1f);
}