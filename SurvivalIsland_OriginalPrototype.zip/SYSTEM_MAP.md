# System Map

## Core loop
Explore → gather → craft → build → hunt/defend → survive → save/load.

## Player
CharacterController
- movement
- gravity
- camera-relative direction
- touch-compatible input

## Survival
SurvivalStats
- health
- hunger
- thirst
- stamina
- damage / respawn

## World
WorldGenerator
- procedural island
- ocean
- resource spawning
- deterministic seed

## Combat
WeaponSystem
- melee raycast
- ranged raycast
- damage interface

## AI
WildlifeAI
- wander
- detect player
- flee

## Economy / progression
Inventory
- stackable items
- hotbar selection

CraftingSystem
- axe
- bow
- wall

BuildingSystem
- preview
- placement

## Presentation
MobileHUD
- status
- action buttons
- virtual movement input

DayNightCycle
- directional light
- time progression

## Persistence
SaveSystem
- JSON save
- automatic save on pause/quit

## Production upgrades recommended
- object pooling
- addressable assets
- animation controller
- IK
- NavMesh / NavMeshComponents
- server authority / anti-cheat
- multiplayer replication
- proper touch joystick implementation
- inventory drag/drop
- recipe data as ScriptableObjects
- chunk streaming
- LOD + occlusion culling
- audio/VFX
- localization
- settings and graphics quality
- cloud save
